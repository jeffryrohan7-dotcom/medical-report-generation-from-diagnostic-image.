// API Configuration for Medical Emergency Triage App
// IMPORTANT: Since this is a pure frontend application, API keys will be visible in the browser.
// For production use, consider using a backend proxy to secure your API keys.
// Alternatively, use restricted API keys with domain/URL restrictions.

// To use this file:
// 1. Get your Google Gemini API key from: https://makersuite.google.com/app/apikey
// 2. Replace 'YOUR_GEMINI_API_KEY_HERE' with your actual API key below
// 3. Optionally configure a custom LibreTranslate endpoint (default uses public instance)

export const config = {
    // Google Gemini API Key
    // Get your key from: https://makersuite.google.com/app/apikey
    GEMINI_API_KEY: 'AIzaSyA7-YYMfrm8gFQpQKltdIYhqujzH3TV1Ds',
    
    // LibreTranslate API endpoint
    // Default: Public LibreTranslate instance (https://libretranslate.com)
    // For self-hosted instance, change this to your server URL
    // Example: 'https://your-translate-server.com/translate'
    TRANSLATE_API_URL: 'https://libretranslate.com/translate'
};

// Security Note:
// In a production environment, you should NEVER expose API keys in frontend code.
// Consider implementing one of the following solutions:
// 1. Use a simple backend proxy server to handle API calls
// 2. Use Google Cloud API key restrictions (domain, IP, referrer restrictions)
// 3. Use environment variables with a build process that injects keys server-side
// 4. Implement rate limiting and usage monitoring

