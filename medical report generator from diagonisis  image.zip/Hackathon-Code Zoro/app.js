// Medical Emergency Triage Application
// Main application logic with Gemini API and LibreTranslate integration

import { config } from './config.js';

// Application State
let currentImageFile = null;
let currentLanguage = 'en';
const BASE_SECTION_LINES = 1;
const EXTRA_SECTION_LINES = 1;
let sectionLineLimit = BASE_SECTION_LINES;

// UI Elements - will be initialized when DOM is ready
let elements = {};

// Language codes mapping
const languageMap = {
    'en': 'en',
    'hi': 'hi', // Hindi
    'ta': 'ta', // Tamil
    'ml': 'ml', // Malayalam
    'te': 'te', // Telugu
    'ms': 'ms' // Malay (Bahasa Melayu)
};

// --- Initialization Functions ---

// Initialize Application
function init() {
    // Initialize DOM elements
    elements = {
        languageSelect: document.getElementById('languageSelect'),
        ageInput: document.getElementById('ageInput'),
        genderInput: document.getElementById('genderInput'),
        symptomsInput: document.getElementById('symptomsInput'),
        analyzeTextBtn: document.getElementById('analyzeTextBtn'),
        imageFileInput: document.getElementById('imageFileInput'),
        uploadImageBtn: document.getElementById('uploadImageBtn'),
        captureImageBtn: document.getElementById('captureImageBtn'),
        imagePreview: document.getElementById('imagePreview'),
        previewImg: document.getElementById('previewImg'),
        removeImageBtn: document.getElementById('removeImageBtn'),
        analyzeImageBtn: document.getElementById('analyzeImageBtn'),
        cameraModal: document.getElementById('cameraModal'),
        videoStream: document.getElementById('videoStream'),
        captureBtn: document.getElementById('captureBtn'),
        cancelCameraBtn: document.getElementById('cancelCameraBtn'),
        captureCanvas: document.getElementById('captureCanvas'),
        closeModal: document.querySelector('.close-modal'),
        responseSection: document.getElementById('responseSection'),
        diagnosisContent: document.getElementById('diagnosisContent'),
        criticalStepsContent: document.getElementById('criticalStepsContent'),
        homeTreatmentContent: document.getElementById('homeTreatmentContent'),
        loadingIndicator: document.getElementById('loadingIndicator'),
        errorDisplay: document.getElementById('errorDisplay'),
        welcomeMessage: document.getElementById('welcomeMessage')
    };
    
    checkAPIKeys();
    setupEventListeners();
    updateWelcomeMessage();
}

// Check if API keys are configured
function checkAPIKeys() {
    if (!config.GEMINI_API_KEY) {
        showError('⚠️ Please configure your Gemini API key in config.js');
    }
}

// Setup all event listeners
function setupEventListeners() {
    // Language selector
    elements.languageSelect.addEventListener('change', (e) => {
        currentLanguage = e.target.value;
        updateWelcomeMessage();
    });

    // Text analysis
    elements.analyzeTextBtn.addEventListener('click', handleTextAnalysis);

    // Image upload
    elements.uploadImageBtn.addEventListener('click', () => {
        elements.imageFileInput.click();
    });

    elements.imageFileInput.addEventListener('change', handleImageFileSelect);

    // Camera capture
    elements.captureImageBtn.addEventListener('click', openCameraModal);
    elements.captureBtn.addEventListener('click', captureFromCamera);
    elements.cancelCameraBtn.addEventListener('click', closeCameraModal);
    elements.closeModal.addEventListener('click', closeCameraModal);

    // Remove image
    elements.removeImageBtn.addEventListener('click', removeImage);

    // Image analysis
    elements.analyzeImageBtn.addEventListener('click', handleImageAnalysis);
}

// Update welcome message based on language
async function updateWelcomeMessage() {
    if (!elements.welcomeMessage) return;
    
    const defaultMessage = "Hello! I'm here to help you today. What can I do for you?";
    
    if (currentLanguage === 'en') {
        elements.welcomeMessage.innerHTML = `<p>${defaultMessage}</p>`;
    } else {
        try {
            const translated = await translateText(defaultMessage, 'en', currentLanguage);
            elements.welcomeMessage.innerHTML = `<p>${translated}</p>`;
        } catch (error) {
            elements.welcomeMessage.innerHTML = `<p>${defaultMessage} (Translation Failed)</p>`;
        }
    }
}


// --- Core Analysis Handlers ---

// Handle text analysis
async function handleTextAnalysis() {
    const age = elements.ageInput.value.trim();
    const gender = elements.genderInput.value.trim();
    const symptoms = elements.symptomsInput.value.trim();
    sectionLineLimit = BASE_SECTION_LINES;

    if (!age || !gender || !symptoms) {
        showError('Please provide age, gender, and symptoms before analysis.');
        return;
    }

    if (Number(age) <= 0 || Number(age) > 120) {
        showError('Please enter a valid age between 1 and 120.');
        return;
    }

    if (!config.GEMINI_API_KEY) {
        showError('API key not configured. Please set GEMINI_API_KEY in config.js');
        return;
    }

    try {
        showLoading(true);
        hideError();

        // Translate input if not English (Needed for Gemini prompt consistency)
        const patientSummary = buildPatientSummary({
            age,
            gender,
            symptoms
        });

        if (isHeavySymptom(symptoms)) {
            sectionLineLimit = BASE_SECTION_LINES + EXTRA_SECTION_LINES;
        }

        let translatedInput = patientSummary;
        if (currentLanguage !== 'en') {
            translatedInput = await translateText(patientSummary, currentLanguage, 'en');
        }

        // Analyze with Gemini
        const analysis = await analyzeWithGemini(translatedInput, 'text');

        // Translate response back to selected language
        let finalResponse = analysis;
        if (currentLanguage !== 'en') {
            finalResponse = await translateText(analysis, 'en', currentLanguage);
        }

        displayResponse(finalResponse);
    } catch (error) {
        console.error('Text analysis error:', error);
        showError(`Error analyzing text: ${error.message}`);
    } finally {
        showLoading(false);
    }
}

// Handle image analysis
async function handleImageAnalysis() {
    if (!currentImageFile) {
        showError('Please select or capture an image first');
        return;
    }

    if (!config.GEMINI_API_KEY) {
        showError('API key not configured. Please set GEMINI_API_KEY in config.js');
        return;
    }

    try {
        showLoading(true);
        hideError();

        // Convert image to base64
        const base64Image = await fileToBase64(currentImageFile);

        // Analyze with Gemini Vision
        const analysis = await analyzeWithGemini(base64Image, 'image');

        sectionLineLimit = BASE_SECTION_LINES;

        // Translate response if needed
        let finalResponse = analysis;
        if (currentLanguage !== 'en') {
            finalResponse = await translateText(analysis, 'en', currentLanguage);
        }

        displayResponse(finalResponse);
    } catch (error) {
        console.error('Image analysis error:', error);
        showError(`Error analyzing image: ${error.message}`);
    } finally {
        showLoading(false);
    }
}


// --- Image Handling Functions ---

// Handle image file selection
function handleImageFileSelect(event) {
    const file = event.target.files[0];
    if (file && file.type.startsWith('image/')) {
        currentImageFile = file;
        displayImagePreview(file);
        elements.analyzeImageBtn.style.display = 'block';
    } else {
        showError('Please select a valid image file');
    }
}

// Open camera modal
async function openCameraModal() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: 'environment' } 
        });
        elements.videoStream.srcObject = stream;
        elements.cameraModal.style.display = 'block';
    } catch (error) {
        console.error('Camera access error:', error);
        showError('Unable to access camera. Please check permissions or upload an image instead.');
    }
}

// Close camera modal
function closeCameraModal() {
    const stream = elements.videoStream.srcObject;
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
        elements.videoStream.srcObject = null;
    }
    elements.cameraModal.style.display = 'none';
}

// Capture image from camera
function captureFromCamera() {
    const video = elements.videoStream;
    const canvas = elements.captureCanvas;
    const context = canvas.getContext('2d');

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0, canvas.width, canvas.height); // Added dimensions

    canvas.toBlob((blob) => {
        currentImageFile = new File([blob], 'capture.jpg', { type: 'image/jpeg' });
        displayImagePreview(currentImageFile);
        elements.analyzeImageBtn.style.display = 'block';
        closeCameraModal();
    }, 'image/jpeg', 0.95);
}

// Display image preview
function displayImagePreview(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
        elements.previewImg.src = e.target.result;
        elements.imagePreview.style.display = 'block';
    };
    reader.readAsDataURL(file);
}

// Remove image
function removeImage() {
    currentImageFile = null;
    elements.imagePreview.style.display = 'none';
    elements.analyzeImageBtn.style.display = 'none';
    elements.imageFileInput.value = '';
}

// Convert file to base64
function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
            const base64 = reader.result.split(',')[1];
            resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}


// --- Gemini API Integration ---

// Analyze with Gemini API
async function analyzeWithGemini(input, type) {
    const apiKey = config.GEMINI_API_KEY;
    const model = 'gemini-2.5-flash'; 
    
    // Doctor persona prompt - UPDATED TO USE XML TAGS FOR RELIABLE PARSING
    const doctorPrompt = `You are an extremely kind, reassuring, and highly competent doctor. Your responses should be warm, professional, and helpful. Never use words like "panic" or "relax" - instead, provide calm, confident guidance.

Structure your entire response using exactly three XML tags: <DIAGNOSIS>, <STEPS>, and <HOME>. 
The content inside each tag must follow these rules:

1.  <DIAGNOSIS>: Provide your assessment and prioritized differential diagnoses. Use one concise line, adding a second urgent line only if the case sounds critical.
2.  <STEPS>: List the immediate critical step or medicine. Use one decisive line, adding an optional second line only when life-threatening details demand it.
3.  <HOME>: Offer one precise home/self-care instruction, adding an optional second line only if symptoms are severe.

Keep the text inside the tags precise, decisive, and compassionate. Do not include any text outside of the three required XML tags.`;

    let requestBody;
    let endpoint;

    endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

    if (type === 'text') {
        requestBody = {
            contents: [{
                parts: [{
                    text: `${doctorPrompt}\n\nPatient Notes:\n${input}`
                }]
            }]
        };
    } else {
        // Image analysis
        requestBody = {
            contents: [{
                parts: [
                    {
                        text: `${doctorPrompt}\n\nPlease analyze this medical image and identify the condition, cause (e.g., what insect bit the patient), and provide medical solutions based on the structured format.`
                    },
                    {
                        inline_data: {
                            mime_type: currentImageFile.type || "image/jpeg", // Use actual MIME type
                            data: input
                        }
                    }
                ]
            }]
        };
    }
    
    // Safety setting to allow responses for medical content (important for triage)
    const safetySetting = {
        category: 'HARM_CATEGORY_MEDICAL',
        threshold: 'BLOCK_NONE',
    };

    // Add safety settings to the request body
    requestBody.contents[0].parts.push({
        text: JSON.stringify({ safetySettings: [safetySetting] })
    });

    const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(`Gemini API Failed (${response.status}): ${errorData.error?.message || 'Unknown API error.'}`);
    }

    const data = await response.json();
    const generatedText = data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response generated';

    return generatedText;
}


// --- Translation Functions ---

// Translate text with fallback strategy
async function translateText(text, sourceLang, targetLang) {
    if (sourceLang === targetLang || !text) {
        return text;
    }

    const supportedLibreLangs = ['en', 'hi', 'ta', 'ml', 'te', 'ms'];
    const shouldUseLibre = config.TRANSLATE_API_URL && supportedLibreLangs.includes(sourceLang) && supportedLibreLangs.includes(targetLang);

    if (shouldUseLibre) {
        try {
            const libreTranslation = await translateWithLibre(text, sourceLang, targetLang);
            if (libreTranslation) {
                return libreTranslation;
            }
        } catch (error) {
            console.warn('LibreTranslate failed, attempting fallback...', error);
        }
    }

    try {
        const fallbackTranslation = await translateWithGoogle(text, sourceLang, targetLang);
        if (fallbackTranslation) {
            return fallbackTranslation;
        }
    } catch (error) {
        console.error('Fallback translation failed:', error);
    }

    // Fallback to original text if translation fails
    return text;
}

async function translateWithLibre(text, sourceLang, targetLang) {
    const translateUrl = config.TRANSLATE_API_URL || 'https://libretranslate.com/translate';
    
    const response = await fetch(translateUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            q: text,
            source: sourceLang,
            target: targetLang,
            format: 'text'
        })
    });

    if (!response.ok) {
        throw new Error(`Translation failed: ${response.status}`);
    }

    const data = await response.json();
    return data.translatedText || '';
}

async function translateWithGoogle(text, sourceLang, targetLang) {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(sourceLang)}&tl=${encodeURIComponent(targetLang)}&dt=t&q=${encodeURIComponent(text)}`;
    
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Google Translate fallback failed: ${response.status}`);
    }

    const data = await response.json();
    if (!Array.isArray(data) || !Array.isArray(data[0])) {
        return '';
    }

    const translated = data[0].map(part => part[0]).join(' ');
    return translated.trim();
}


// --- Utility and Display Functions ---

function buildPatientSummary({ age, gender, symptoms }) {
    const normalizedGender = normalizeGender(gender);
    const ageText = `${age}-year-old`;
    const severityNote = isHeavySymptom(symptoms) ? '\nSeverity flag: symptoms appear critical.' : '';
    return `${ageText} ${normalizedGender} patient.\nKey symptoms: ${symptoms}${severityNote}`;
}

function normalizeGender(gender) {
    if (!gender) return 'adult';
    switch (gender.toLowerCase()) {
        case 'male':
            return 'male';
        case 'female':
            return 'female';
        default:
            return 'adult';
    }
}

function isHeavySymptom(symptoms = '') {
    const heavyKeywords = [
        'severe', 'crushing', 'chest pain', 'heart attack', 'stroke', 'unconscious', 'faint', 
        'bleeding', 'hemorrhage', 'difficulty breathing', 'shortness of breath', 'dyspnea', 
        'no pulse', 'cardiac', 'shock', 'seizure', 'convulsion', 'paralysis', 'burn', 'trauma'
    ];

    const lowered = symptoms.toLowerCase();
    return heavyKeywords.some(keyword => lowered.includes(keyword));
}

// Display response in structured format
function displayResponse(responseText) {
    // Parse the response into three sections
    const sections = parseResponse(responseText);
    
    const diagnosisContent = truncateLines(sections.diagnosis, sectionLineLimit);
    const criticalContent = truncateLines(sections.criticalSteps, sectionLineLimit);
    const homeContent = truncateLines(sections.homeTreatment, sectionLineLimit);

    elements.diagnosisContent.innerHTML = formatContent(diagnosisContent) || 'Analysis will appear here...';
    elements.criticalStepsContent.innerHTML = formatContent(criticalContent) || 'Critical steps will appear here...';
    elements.homeTreatmentContent.innerHTML = formatContent(homeContent) || 'Home treatment will appear here...';
    
    elements.responseSection.style.display = 'block';
    
    // Scroll to response
    elements.responseSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Helper to convert basic markdown (like lists) to HTML
function formatContent(text) {
    if (!text) return '';
    // Convert bulleted lists to HTML list items
    let html = text.replace(/^- (.*)/gm, '<li>$1</li>');
    html = html.replace(/\* (.*)/gm, '<li>$1</li>');
    
    // Wrap list items in <ul> or <ol> if lists are present
    if (html.includes('<li>')) {
        // Simple heuristic to avoid double wrapping
        if (!html.startsWith('<ul>') && !html.startsWith('<ol>')) {
            html = `<ul>${html}</ul>`;
        }
    }
        
    // Simple paragraph breaks
    html = html.replace(/\n\n/g, '<br><br>');
    
    return html;
}

// Parse response text into three sections - UPDATED FOR XML TAGS
function parseResponse(text) {
    const sections = {
        diagnosis: '',
        criticalSteps: '',
        homeTreatment: ''
    };

    // Use simple string methods to reliably extract content between XML tags
    const extractContent = (tag) => {
        const startTag = `<${tag}>`;
        const endTag = `</${tag}>`;
        const start = text.indexOf(startTag);
        const end = text.indexOf(endTag);

        if (start !== -1 && end !== -1 && end > start) {
            return text.substring(start + startTag.length, end).trim();
        }
        return '';
    };

    sections.diagnosis = extractContent('DIAGNOSIS');
    sections.criticalSteps = extractContent('STEPS');
    sections.homeTreatment = extractContent('HOME');

    return sections;
}

function truncateLines(text, maxLines = sectionLineLimit) {
    if (!text) return '';
    const lines = text
        .split('\n')
        .map(line => line.trimEnd())
        .filter(line => line.trim() !== '');
    return lines.slice(0, maxLines).join('\n');
}

// Show/hide loading indicator
function showLoading(show) {
    elements.loadingIndicator.style.display = show ? 'block' : 'none';
    elements.analyzeTextBtn.disabled = show;
    elements.analyzeImageBtn.disabled = show;
}

// Show error message
function showError(message) {
    if (!elements.errorDisplay) {
        console.error(message);
        return;
    }
    elements.errorDisplay.textContent = message;
    elements.errorDisplay.style.display = 'block';
    setTimeout(() => {
        elements.errorDisplay.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
}

// Hide error message
function hideError() {
    if (elements.errorDisplay) {
        elements.errorDisplay.style.display = 'none';
    }
}

// Initialize on page load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    // DOM is already ready
    init();
}